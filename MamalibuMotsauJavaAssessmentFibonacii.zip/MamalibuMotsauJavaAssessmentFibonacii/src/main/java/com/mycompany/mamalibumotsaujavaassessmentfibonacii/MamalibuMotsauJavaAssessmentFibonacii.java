/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mamalibumotsaujavaassessmentfibonacii;

/**
 *
 * @author Lenovo-User
 */
public class MamalibuMotsauJavaAssessmentFibonacii {

   public static void main(String[] args) {
        int n = 20, firstTerm = 0, secondTerm = 1;
    System.out.println("Fibonacci Series till " + n + " terms:");

    for (int i = 1; i <= n; ++i) {
      System.out.print(firstTerm + ", ");

      // compute the next term
      int nextTerm = firstTerm + secondTerm;
      firstTerm = secondTerm;
      secondTerm = nextTerm;
    }
    }
}
